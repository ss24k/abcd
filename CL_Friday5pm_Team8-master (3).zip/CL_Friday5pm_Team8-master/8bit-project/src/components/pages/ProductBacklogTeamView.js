import React, { useState, useEffect } from 'react';
import AddItem from './AddItem';
import './ProductBacklog.css';

function ProductBacklogTeamView() {
  const [backlogItems, setBacklogItems] = useState(() => {
    const savedItems = localStorage.getItem('backlogItems');
    return savedItems ? JSON.parse(savedItems) : [];
  });

  const [sortCriteria, setSortCriteria] = useState('tag');
  const [sortOrder, setSortOrder] = useState('asc');

  // Save to local storage whenever backlogItems changes
  useEffect(() => {
    localStorage.setItem('backlogItems', JSON.stringify(backlogItems));
  }, [backlogItems]);

  // Count the number of items in each status
  const statusSummary = backlogItems.reduce(
    (summary, item) => {
      summary[item.status] += 1;
      return summary;
    },
    { Pending: 0, 'In Progress': 0, Completed: 0 }
  );

  // Function to add a new item to the backlog
  const handleAddItem = (item) => {
    const newItem = {
      id: backlogItems.length + 1,
      title: item.title,
      priority: item.priority,
      developer: item.developer,
      status: 'Pending', // Default status
    };
    setBacklogItems([...backlogItems, newItem]);
  };

  // Function to handle status changes
  const handleStatusChange = (id, newStatus) => {
    const updatedItems = backlogItems.map((item) =>
      item.id === id ? { ...item, status: newStatus } : item
    );
    setBacklogItems(updatedItems);
  };

  // Sort items
  const sortBacklogItems = (items, criteria, order) => {
    return [...items].sort((a, b) => {
      if (a[criteria] < b[criteria]) return order === 'asc' ? -1 : 1;
      if (a[criteria] > b[criteria]) return order === 'asc' ? 1 : -1;
      return 0;
    });
  };

  const handleSortChange = (event) => {
    const { name, value } = event.target;
    if (name === 'criteria') {
      setSortCriteria(value);
    } else if (name === 'order') {
      setSortOrder(value);
    }
  };

  useEffect(() => {
    const sortedItems = sortBacklogItems(backlogItems, sortCriteria, sortOrder);
    setBacklogItems(sortedItems);
  }, [sortCriteria, sortOrder]);

  return (
    <div className="product-backlog">
      <h1>Product Backlog</h1>

      {/* Status summary */}
      <div className="status-summary">
        <p>Pending: {statusSummary.Pending}</p>
        <p>In Progress: {statusSummary['In Progress']}</p>
        <p>Completed: {statusSummary.Completed}</p>
      </div>

      {/* Sort Controls */}
      <div className="sort-controls">
        <label htmlFor="sort-by">Sort by:</label>
        <select
          id="sort-by"
          name="criteria"
          value={sortCriteria}
          onChange={handleSortChange}
        >
          <option value="tag">Tag</option>
          <option value="priority">Priority</option>
          <option value="status">Status</option>
        </select>

        <label htmlFor="sort-order">Order:</label>
        <select
          id="sort-order"
          name="order"
          value={sortOrder}
          onChange={handleSortChange}
        >
          <option value="asc">Ascending</option>
          <option value="desc">Descending</option>
        </select>
      </div>

      {/* Add new item functionality */}
      <div className="add-task-container">
        <AddItem onAdd={handleAddItem} />
      </div>

      <table className="backlog-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Task</th>
            <th>Priority</th>
            <th>Developer</th>
            <th>Status</th>
            
          </tr>
        </thead>
        <tbody>
          {backlogItems.map((item) => (
            <tr
              key={item.id}
              className={
                item.status === 'Pending'
                  ? 'pending'
                  : item.status === 'In Progress'
                  ? 'in-progress'
                  : 'completed'
              }
            >
              {/* Item ID */}
              <td>{item.id}</td>

              {/* Task Title */}
              <td>{item.title}</td>

              {/* Priority */}
              <td>{item.priority}</td>

              {/* Developer */}
              <td>{item.developer}</td>

              {/* Status Dropdown */}
              <td>
                <select
                  value={item.status}
                  onChange={(e) =>
                    handleStatusChange(item.id, e.target.value)
                  }
                >
                  <option value="Pending">Pending</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Completed">Completed</option>
                </select>

              </td>              
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ProductBacklogTeamView;