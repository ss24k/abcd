import React, { useState } from 'react';

function AddItem({ onAdd }) {
  const [newItem, setNewItem] = useState({ title: '', priority: 'Medium', Developer: 'Daksh' });

  // Handle input changes for the new item
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewItem((prevItem) => ({
      ...prevItem,
      [name]: value,
    }));
  };

  // Handle adding the new item
  const handleAddItem = () => {
    if (newItem.title.trim()) {
      onAdd(newItem); // Pass the new item to the parent component
      setNewItem({ title: '', priority: 'Medium', Developer: 'Daksh' }); // Reset the input fields
    }
  };

  return (
    <div className="add-backlog-item">
      <input
        type="text"
        name="title"
        placeholder="Task Title"
        value={newItem.title}
        onChange={handleInputChange}
      />
      <select
        name="priority"
        value={newItem.priority}
        onChange={handleInputChange}
      >
        <option value="High">High</option>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
      </select>

        {/* Dropdown menu for assigning a developer to the story:*/}
        <select
          name="developer"
          value={newItem.developer}
          onChange={handleInputChange}
        >
        <option value="Daksh">Daksh</option>
        <option value="Chetan">Chetan</option>
        <option value="Gaurav">Gaurav</option>
        <option value="Shaurya">Shaurya</option>
        <option value="Sameeksha">Sameeksha</option>
        <option value="Simran">Simran</option>

      </select>
      <button onClick={handleAddItem}>Add Task</button>
    </div>
  );
}

export default AddItem;
