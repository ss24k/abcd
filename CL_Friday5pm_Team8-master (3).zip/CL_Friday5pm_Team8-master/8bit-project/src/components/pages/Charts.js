import React, { useState, useEffect } from 'react';
import './styles.css'; // Make sure the path to the styles file is correct

const ChartsTabs = () => {
  const [active_Tab, set_Active_Tab] = useState('sprint-review');

  const show_Tab_Change = (tabName) => {
    set_Active_Tab(tabName);
  };

  useEffect(() => {
    // Logic for chart initialization
    const Chart_burndown_Canvas = document.getElementById('Chart_burndown_Canvas');
    const Chart_line_Sprint_Canvas = document.getElementById('Chart_line_Sprint_Canvas');
    const Chart_line_Canvas = document.getElementById('Chart_line_Canvas');

    // You can set up your chart logic here (e.g., using Chart.js)
    if (Chart_burndown_Canvas) {
      // Initialize the Burndown chart
    }
    if (Chart_line_Sprint_Canvas) {
      // Initialize the Sprint Line chart
    }
    if (Chart_line_Canvas) {
      // Initialize the Developer Line chart
    }
  }, []);

  return (
    <div>
      {/* Navigation for Tabs */}
      <div id="dolphincontainer">
        <div id="dolphinnav">
          <ul>
            <li>
              <a
                href="#sprint-review-tab"
                className={active_Tab === 'sprint-review' ? 'current' : ''}
                onClick={() => show_Tab_Change('sprint-review')}
                style={{ fontSize: '22px' }}
              >
                <span>Sprint Review</span>
              </a>
            </li>
            <li>
              <a
                href="#developer-review-tab"
                className={active_Tab === 'developer-review' ? 'current' : ''}
                onClick={() => show_Tab_Change('developer-review')}
                style={{ fontSize: '22px' }}
              >
                <span>Developer Review</span>
              </a>
            </li>
          </ul>
        </div>
      </div>

      {/* Sprint Review Tab Content */}
      {active_Tab === 'sprint-review' && (
        <div id="sprint-review-tab" className="tab-content">
          <h1 style={{ textAlign: 'center' }}>Sprint Review</h1>
          <div className="chart-container">
            <canvas id="Chart_burndown_Canvas"></canvas>
          </div>
        </div>
      )}

      {/* Developer Review Tab Content */}
      {active_Tab === 'developer-review' && (
        <div id="developer-review-tab" className="tab-content">
          <h1 style={{ textAlign: 'center' }}>Developer Review</h1>
          <div className="chart-container">
            <h2 style={{ textAlign: 'center', fontSize: '22px' }}>Accumulation of work hours per sprint</h2>
            <canvas id="Chart_line_Sprint_Canvas"></canvas>
          </div>
          <div className="chart-container">
            <h2 style={{ textAlign: 'center', fontSize: '22px' }}>Accumulation of work hours per sprint for every developer</h2>
            <canvas id="Chart_line_Canvas"></canvas>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChartsTabs;
