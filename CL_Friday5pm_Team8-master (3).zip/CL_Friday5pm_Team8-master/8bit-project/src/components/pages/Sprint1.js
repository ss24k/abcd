import React, { useState, useEffect, useContext } from 'react';
import ProductBacklog from './ProductBacklog';
import './SprintPage.css';
import { ThemeContext } from '../../contexts/theme-context'; // Import the Theme Context

const SprintPage = () => {
  const defaultSprintName = '';
  const allowedSprintNames = ['Sprint 1', 'Sprint 2', 'Sprint 3'];

  const { theme } = useContext(ThemeContext); // Use the theme from context

  const [sprints, setSprints] = useState(() => {
    const savedSprints = localStorage.getItem('sprints');
    return savedSprints ? JSON.parse(savedSprints) : [];
  });

  const [currentSprint, setCurrentSprint] = useState({
    name: defaultSprintName,
    startDate: '',
    endDate: '',
    progress: 'Not Started',
  });

  const [sprintBacklog, setSprintBacklog] = useState(() => {
    const savedSprintBacklog = localStorage.getItem('sprintBacklog');
    return savedSprintBacklog ? JSON.parse(savedSprintBacklog) : [];
  });

  const [productBacklog, setProductBacklog] = useState(() => {
    const savedItems = localStorage.getItem('backlogItems');
    return savedItems ? JSON.parse(savedItems) : [];
  });

  const [isEditing, setIsEditing] = useState(false);
  const [isBacklogEditing, setIsBacklogEditing] = useState(false);

  // State for sorting
  const [sprintSortCriteria, setSprintSortCriteria] = useState('name');
  const [sprintSortOrder, setSprintSortOrder] = useState('asc');
  const [backlogSortCriteria, setBacklogSortCriteria] = useState('id');
  const [backlogSortOrder, setBacklogSortOrder] = useState('asc');
  const [backlogSortDeveloperOrder, setBacklogSortDeveloperOrder] = useState('asc'); // New state for developer sorting

  useEffect(() => {
    localStorage.setItem('sprints', JSON.stringify(sprints));
  }, [sprints]);

  useEffect(() => {
    localStorage.setItem('sprintBacklog', JSON.stringify(sprintBacklog));
  }, [sprintBacklog]);

  useEffect(() => {
    localStorage.setItem('backlogItems', JSON.stringify(productBacklog));
  }, [productBacklog]);

  const handleFieldChange = (field, value) => {
    const updatedSprint = { ...currentSprint, [field]: value };
    setCurrentSprint(updatedSprint);
  };

  const handleSaveSprint = () => {
    if (!allowedSprintNames.includes(currentSprint.name)) {
      alert('Invalid sprint name. Please select one from the available options.');
      return;
    }

    const isNameUsed = sprints.some((sprint) => sprint.name === currentSprint.name);
    if (isNameUsed && !isEditing) {
      alert('This sprint name has already been used. Please choose a different name.');
      return;
    }

    if (currentSprint.startDate && currentSprint.endDate && currentSprint.startDate > currentSprint.endDate) {
      alert('Start date cannot be after the end date. Please adjust the dates.');
      return;
    }

    if (isEditing) {
      const updatedSprints = sprints.map((sprint) =>
        sprint.name === currentSprint.name ? currentSprint : sprint
      );
      setSprints(updatedSprints);
    } else {
      setSprints([...sprints, currentSprint]);
    }

    setIsEditing(false);
    setCurrentSprint({
      name: defaultSprintName,
      startDate: '',
      endDate: '',
      status: 'Static',
      progress: 'Not Started',
    });
  };

  const handleStatusChange = (id, newStatus) => {
    const updatedItems = sprintBacklog.map((item) =>
      item.id === id ? { ...item, status: newStatus } : item
    );
    setSprintBacklog(updatedItems);
  };

  const handleMoveBackToProductBacklog = (item) => {
    if (!productBacklog.some((backlogItem) => backlogItem.id === item.id)) {
      const originalItem = { ...item };
      originalItem.status = 'Pending'; // Reset status to Pending in Product Backlog
      setProductBacklog([...productBacklog, originalItem]);
    }

    const updatedSprintBacklog = sprintBacklog.filter((task) => task.id !== item.id);
    setSprintBacklog(updatedSprintBacklog);
  };

  const handleAddToSprintBacklog = (item) => {
    if (!sprintBacklog.some((backlogItem) => backlogItem.id === item.id)) {
      const newSprintBacklogItem = {
        ...item,
        sprint: currentSprint.name,
        status: 'Pending',
      };
      setSprintBacklog([...sprintBacklog, newSprintBacklogItem]);

      const updatedProductBacklog = productBacklog.filter((backlogItem) => backlogItem.id !== item.id);
      setProductBacklog(updatedProductBacklog);
    }
  };

  const handleEditSprint = (sprintName) => {
    const sprintToEdit = sprints.find((sprint) => sprint.name === sprintName);
    setCurrentSprint(sprintToEdit);
    setIsEditing(true);
  };

  const handleDeleteSprint = (sprintName) => {
    const updatedSprints = sprints.filter((sprint) => sprint.name !== sprintName);
    setSprints(updatedSprints);

    if (currentSprint.name === sprintName) {
      setCurrentSprint({
        name: defaultSprintName,
        startDate: '',
        endDate: '',
        status: 'Static',
        progress: 'Not Started',
      });
    }
  };

  const toggleBacklogEditing = () => {
    if (isBacklogEditing) {
      localStorage.setItem('sprintBacklog', JSON.stringify(sprintBacklog));
      alert('Sprint backlog has been saved!');
    }
    setIsBacklogEditing(!isBacklogEditing);
  };

  const filteredSprintBacklog = sprintBacklog.filter(item => item.sprint === currentSprint.name);

  const sortSprints = (sprints) => {
    return [...sprints].sort((a, b) => {
      if (sprintSortCriteria === 'name') {
        return sprintSortOrder === 'asc' ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name);
      } else if (sprintSortCriteria === 'startDate') {
        return sprintSortOrder === 'asc'
          ? new Date(a.startDate) - new Date(b.startDate)
          : new Date(b.startDate) - new Date(a.startDate);
      } else if (sprintSortCriteria === 'endDate') {
        return sprintSortOrder === 'asc'
          ? new Date(a.endDate) - new Date(b.endDate)
          : new Date(b.endDate) - new Date(a.endDate);
      } else {
        return 0;
      }
    });
  };

  const sortBacklog = (backlog) => {
    return [...backlog].sort((a, b) => {
      if (backlogSortCriteria === 'title') {
        return backlogSortOrder === 'asc' ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title);
      } else if (backlogSortCriteria === 'priority') {
        return backlogSortOrder === 'asc' ? a.priority.localeCompare(b.priority) : b.priority.localeCompare(a.priority);
      } else if (backlogSortCriteria === 'status') {
        return backlogSortOrder === 'asc' ? a.status.localeCompare(b.status) : b.status.localeCompare(a.status);
      } else if (backlogSortCriteria === 'developer') { // New sorting by developer
        return backlogSortDeveloperOrder === 'asc' ? a.developer.localeCompare(b.developer) : b.developer.localeCompare(a.developer);
      } else {
        return 0;
      }
    });
  };

  const sortedSprints = sortSprints(sprints);
  const sortedSprintBacklog = sortBacklog(filteredSprintBacklog);

  return (
    <div className={`sprint-page theme-${theme}`}> {/* Apply theme class */}
      <h1>Sprint -1</h1>

      <div className="sprint-details">
        <div className="field-group">
          <label>Sprint Name: </label>
          <select
            value={currentSprint.name}
            onChange={(e) => handleFieldChange('name', e.target.value)}
          >
            <option value={defaultSprintName}>{defaultSprintName}</option>
            {allowedSprintNames.map((name) => (
              <option
                key={name}
                value={name}
                disabled={sprints.some(sprint => sprint.name === name && sprint.progress === 'Completed')}
              >
                {name}
              </option>
            ))}
          </select>
        </div>

        <div className="field-group">
          <label>Start Date: </label>
          <input
            type="date"
            value={currentSprint.startDate}
            onChange={(e) => handleFieldChange('startDate', e.target.value)}
          />
        </div>

        <div className="field-group">
          <label>End Date: </label>
          <input
            type="date"
            value={currentSprint.endDate}
            onChange={(e) => handleFieldChange('endDate', e.target.value)}
          />
        </div>

        <div className="field-group">
          <label>Progress: </label>
          <select
            value={currentSprint.progress}
            onChange={(e) => {
              const newProgress = e.target.value;
              handleFieldChange('progress', newProgress);
            }}
          >
            <option value="Not Started">Not Started</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>
        </div>

        <button onClick={handleSaveSprint}>
          {isEditing ? 'Save Modified Details' : 'Save Sprint'}
        </button>
      </div>

      <div className="sprint-list">
        <h2>Sprints</h2>

        {/* Sorting Controls for Sprints */}
        <div className="sort-controls">
          <label htmlFor="sprint-sort-criteria">Sort by:</label>
          <select
            id="sprint-sort-criteria"
            value={sprintSortCriteria}
            onChange={(e) => setSprintSortCriteria(e.target.value)}
          >
            <option value="name">Name</option>
            <option value="startDate">Start Date</option>
            <option value="endDate">End Date</option>
          </select>

          <label htmlFor="sprint-sort-order">Order:</label>
          <select
            id="sprint-sort-order"
            value={sprintSortOrder}
            onChange={(e) => setSprintSortOrder(e.target.value)}
          >
            <option value="asc">Ascending</option>
            <option value="desc">Descending</option>
          </select>
        </div>

        {sprints.length === 0 ? (
          <p>No sprints available.</p>
        ) : (
          <ul>
            {sortedSprints.map((sprint) => (
              <li key={sprint.name} className="sprint-item">
                <div><strong>Name:</strong> {sprint.name}</div>
                <div><strong>Start Date:</strong> {sprint.startDate}</div>
                <div><strong>End Date:</strong> {sprint.endDate}</div>
                <div><strong>Status:</strong> {sprint.status}</div>
                <div><strong>Progress:</strong> {sprint.progress}</div>
                <button onClick={() => handleEditSprint(sprint.name)}>Edit</button>
                <button onClick={() => handleDeleteSprint(sprint.name)}>Delete</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="backlog-section">
        <h2>Sprint Backlog for {currentSprint.name}</h2>

        {/* Sorting Controls for Backlog */}
        <div className="sort-controls">
          <label htmlFor="backlog-sort-criteria">Sort by:</label>
          <select
            id="backlog-sort-criteria"
            value={backlogSortCriteria}
            onChange={(e) => setBacklogSortCriteria(e.target.value)}
          >
            <option value="title">Title</option>
            <option value="priority">Priority</option>
            <option value="status">Status</option>
            <option value="developer">Developer</option> {/* Added sorting by developer */}
          </select>

          <label htmlFor="backlog-sort-order">Order:</label>
          <select
            id="backlog-sort-order"
            value={backlogSortOrder}
            onChange={(e) => setBacklogSortOrder(e.target.value)}
          >
            <option value="asc">Ascending</option>
            <option value="desc">Descending</option>
          </select>
        </div>

        {filteredSprintBacklog.length === 0 ? (
          <p>No items in sprint backlog</p>
        ) : (
          <table className="backlog-table">
            <thead>
              <tr>
                <th>Task</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Developer</th> {/* New column for Developer */}
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedSprintBacklog.map((item) => (
                <tr key={item.id}>
                  <td>{item.title}</td>
                  <td>{item.priority}</td>
                  <td>
                    <select
                      value={item.status}
                      onChange={(e) => handleStatusChange(item.id, e.target.value)}
                    >
                      <option value="Pending">Pending</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </td>
                  <td>{item.developer}</td> {/* Display developer name */}
                  <td>
                    {item.status !== 'In Progress' && item.status !== 'Completed' && (
                      <button onClick={() => handleMoveBackToProductBacklog(item)}>
                        Move to Product Backlog
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <button onClick={toggleBacklogEditing}>
        {isBacklogEditing ? 'Save Sprint Backlog' : 'Edit Backlog'}
      </button>

      <ProductBacklog
        sprints={sprints}
        onAddToSprintBacklog={handleAddToSprintBacklog}
      />
    </div>
  );
};

export default SprintPage;
