import React from 'react';

function DeleteItem({ id, onDelete }) {
  return (
    <button onClick={() => onDelete(id)}>Delete</button>
  );
}

export default DeleteItem;


