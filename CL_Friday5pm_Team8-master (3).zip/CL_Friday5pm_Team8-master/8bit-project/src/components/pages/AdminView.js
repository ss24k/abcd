import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AdminView.css'; // Make sure to use appropriate CSS for styling

function AdminView() {
    const [tasks, setTasks] = useState([]);  // Tasks from the product backlog
    const [users, setUsers] = useState([]);  // List of developers
    const [newEmail, setNewEmail] = useState('');
    const [newPassword, setNewPassword] = useState('');

    // Fetch tasks and users on component mount
    useEffect(() => {
        fetchTasks();
        fetchUsers();
    }, []);

    const fetchTasks = async () => {
        // Fetch tasks from local storage, which contain UUIDs
        setTasks(JSON.parse(localStorage.getItem('backlogItems')) || []);
    };

    const fetchUsers = async () => {
        try {
            const response = await axios.get('http://localhost:5000/users');
            setUsers(response.data);
        } catch (error) {
            console.error('Failed to fetch users:', error);
        }
    };

    const handleAddUser = async () => {
        try {
            const response = await axios.post('http://localhost:5000/users', {
                email: newEmail,
                password: newPassword
            });
            fetchUsers();  // Refresh the list of users
            setNewEmail('');
            setNewPassword('');
            alert('User added: ' + newEmail);
        } catch (error) {
            alert('Failed to add user: ' + error.response.data.message);
        }
    };

    const handleDeleteUser = async (email) => {
        try {
            const response = await axios.delete(`http://localhost:5000/users/${email}`);
            fetchUsers();  // Refresh the list of users
            alert('User deleted: ' + email);
        } catch (error) {
            alert('Failed to delete user: ' + error.response.data.message);
        }
    };

    return (
        <div className="admin-view">
            <h2>Manage Developers</h2>
            <h3>Add New</h3>
            <div className="user-input">
                <input
                    type="text"
                    value={newEmail}
                    onChange={e => setNewEmail(e.target.value)}
                    placeholder="Email"
                />
                <input
                    type="password"
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    placeholder="Password"
                />
                <button onClick={handleAddUser}>Add Developer</button>
            </div>

            <h3>Current Developers</h3>
            <div className="user-list">
                <table className="user-table">
                    <tbody>
                        {users.map(user => (
                            <tr key={user.email} className="user-row">
                                <td>{user.email}</td>
                                <td>
                                    <button className="remove-button" onClick={() => handleDeleteUser(user.email)}>
                                        Remove
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <h2>Product Backlog</h2>
            <table className="backlog-table">
                <thead>
                    <tr>
                        <th>ID</th> {/* Renamed from # to ID */}
                        <th>Task</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Assigned To</th>
                        <th>Time Spent (hrs)</th>
                    </tr>
                </thead>
                <tbody>
                    {tasks.map((task, index) => (
                        <tr key={task.id}>
                            <td>{index + 1}</td> {/* Display sequential number as ID */}
                            <td>{task.title}</td>
                            <td>{task.priority}</td>
                            <td>{task.status}</td>
                            <td>
                                <select defaultValue="">
                                    <option value="" disabled>Select Developer</option>
                                    {users.map(user => (
                                        <option key={user.email} value={user.email}>{user.email}</option>
                                    ))}
                                </select>
                            </td>
                            <td><input type="number" placeholder="Hours" min="0" /></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AdminView;
