// Header.js
import React, { useContext } from 'react';
import { ThemeContext } from '../contexts/theme-context';
import './Header.css';
import TranslateComponent from './TranslationComponent'; // Adjust the path if necessary

const Header = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <header className={`header theme-${theme}`}>
      <h1>Theme Switcher</h1>
      <button onClick={toggleTheme}>
        Switch to{' '}
        {theme === 'dark'
          ? 'Light'
          : theme === 'light'
          ? 'High Contrast'
          : 'Dark'}{' '}
        Mode
      </button>
      <TranslateComponent />
    </header>
  );
};

export default Header;
