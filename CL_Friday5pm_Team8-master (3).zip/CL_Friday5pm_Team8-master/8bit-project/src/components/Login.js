import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Login.css';

function Login({ setIsAuthenticated, setUserRole }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate(); // For redirection

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      // Send the login request to the backend
      const response = await axios.post('http://localhost:5000/login', {
        email: username,
        password: password
      });

      // Handle the response from the backend
      if (response.status === 200) {
        const { role } = response.data;
        // Store role-specific information based on the server response
        localStorage.setItem('authenticated', 'true');
        localStorage.setItem('role', role);
        setIsAuthenticated(true);
        setUserRole(role);

        // Redirect to the home page or dashboard
        navigate('/');
      }
    } catch (error) {
      setErrorMessage('Invalid credentials, please try again.');
    }
  };

  return (
    <div className="login-container">
      {/* Add the logo directly using the relative path */}
      <img src="/8bit.jpg" alt="Logo" className="login-logo" />
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Username:
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Enter your email"
          />
        </label>
        <br />
        <label>
          Password:
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
          />
        </label>
        <br />
        <button type="submit">Login</button>
      </form>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
    </div>
  );
}

export default Login;
