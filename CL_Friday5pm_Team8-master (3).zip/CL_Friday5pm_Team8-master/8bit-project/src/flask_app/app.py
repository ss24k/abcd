from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS to allow communication with React frontend

# Updated users dictionary
users = {
    "scrummaster@gmail.com": {"password": "1234", "role": "scrum-master"},
    "team@gmail.com": {"password": "4321", "role": "team-member"}
}

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    # Validate user credentials
    user = users.get(email)
    if user and user['password'] == password:
        return jsonify({'message': 'Login successful!', 'role': user['role']}), 200
    return jsonify({'message': 'Invalid credentials'}), 401


@app.route('/users', methods=['GET'])
def get_users():
    return jsonify([{'email': k, 'role': v['role']} for k, v in users.items()])


@app.route('/users', methods=['POST'])
def add_user():
    data = request.get_json()
    email = data.get('email')
    if email in users:
        return jsonify({'message': 'User already exists'}), 409
    users[email] = {'password': data.get('password'), 'role': 'team-member'}
    print(users)  # Debug: Print users dictionary to see if it is updated
    return jsonify({'message': 'User added successfully', 'users': users}), 201


@app.route('/users/<email>', methods=['DELETE'])
def delete_user(email):
    if email in users:
        del users[email]
        return jsonify({'message': 'User deleted successfully'}), 200
    return jsonify({'message': 'User not found'}), 404

if __name__ == '__main__':
    app.run(debug=True)
