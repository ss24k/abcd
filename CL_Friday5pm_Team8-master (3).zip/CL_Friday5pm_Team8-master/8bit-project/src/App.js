import './App.css';
import Navbar from './components/Navbar';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Home from './components/pages/Home';
import ProductBacklog from './components/pages/ProductBacklog';
import ProductBacklogTeamView from './components/pages/ProductBacklogTeamView';
import Sprint1 from './components/pages/Sprint1';
import Sprint2 from './components/pages/Sprint2';
import Sprint3 from './components/pages/Sprint3';
import Charts from './components/pages/Charts';
import Login from './components/Login';
import AdminView from './components/pages/AdminView';
import { useEffect, useState } from 'react';
import { ThemeProvider } from './contexts/theme-context';
import Header from './components/Header';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [role, setUserRole] = useState('');

  useEffect(() => {
    const authStatus = localStorage.getItem('authenticated');
    setIsAuthenticated(authStatus === 'true');
    const userRole = localStorage.getItem('role');
    setUserRole(userRole || '');
  }, []);

  return (
    <ThemeProvider>
      <Router>
        {isAuthenticated && <Navbar setIsAuthenticated={setIsAuthenticated} setUserRole={setUserRole} />}

        <Header />

        <Routes>
          <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} setUserRole={setUserRole} />} />
          <Route path="/" element={isAuthenticated ? <Home /> : <Navigate to="/login" />} />
          <Route path="/productbacklog" element={isAuthenticated ? (
            role === 'team-member' ? <ProductBacklogTeamView /> :
            role === 'scrum-master' ? <ProductBacklog /> :
            <Navigate to="/login" />) : <Navigate to="/login" />} />
          <Route path="/sprint1" element={isAuthenticated ? <Sprint1 /> : <Navigate to="/login" />} />
          <Route path="/sprint2" element={isAuthenticated ? <Sprint2 /> : <Navigate to="/login" />} />
          <Route path="/sprint3" element={isAuthenticated ? <Sprint3 /> : <Navigate to="/login" />} />
          <Route path="/charts" element={isAuthenticated ? <Charts /> : <Navigate to="/login" />} />
          <Route path="/adminview" element={isAuthenticated && role === 'scrum-master' ? <AdminView /> : <Navigate to="/login" />} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;

